// vite.config.js
export default {
  server: {
    allowedHosts: [
      '93b5166e-39da-41f0-a71b-b29f975048d7-00-2yhpml9ri7q2g.sisko.replit.dev'
    ]
  }
};
